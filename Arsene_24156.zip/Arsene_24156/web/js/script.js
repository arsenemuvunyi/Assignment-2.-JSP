/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

const registrationForm = document.getElementById("registration-form");
const passwordField = document.getElementById("password");
const confirmPasswordField = document.getElementById("confirm-password");
const passwordMatchMessage = document.getElementById("password-match-message");

registrationForm.addEventListener("submit", function (event) {
    if (passwordField.value !== confirmPasswordField.value) {
        passwordMatchMessage.textContent = "Passwords do not match";
        event.preventDefault(); // Prevent form submission
    } else {
        passwordMatchMessage.textContent = "";
    }
});

