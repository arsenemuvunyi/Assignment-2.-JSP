/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package email;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Willy
 */
public class Mail {
     public static void sendMail(String recepient) throws Exception {
       System.out.println("Preparing to send a mail message.");
       
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
;
        
        final String myEmail = "kenntyfabrice8@gmail.com";
        final String myPassword = "tbzydsbfnvmfyryy";
        
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myEmail, myPassword); 
            } 
        });
        
        Message message = prepareMessage(session, myEmail, recepient);
        Transport.send(message);
        System.out.println("Mail message sent successfully.");
        
    }

    private static Message prepareMessage(Session session, String myEmail, String recepient) {
        Message message = null;
        try {
            message = new MimeMessage(session);
            message.setFrom(new InternetAddress(myEmail));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
            message.setSubject("Email Confirmation  from Web Tech class");
            message.setText("Hello, \n This is a confirmation email that you signed up/filled the student admission form.");
        } catch (Exception ex) {
            Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return message;
    }

    
}
