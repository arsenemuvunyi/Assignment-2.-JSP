/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Willy
 */
@Entity(name="admissions")
@Table(name="admissions")
public class Admission implements Serializable{
   
    @Id
    @Column(name="student_id")
    private Long studentId;
    private String email;
    private String firstName;
    private String lastName;
    private String gender;
    private String faculty;
    private String department;
    private Date dob;
    @Lob
    private byte[] CertificateName;
    @Lob
    private byte[] imageName;
    @Transient
    private String base64Image;
    @Transient
    private String base64Pdf;
   
    public Admission(){
    
    }

    public Admission(Long studentId, String email, String firstName, String lastName, String gender, String faculty, String department, Date dob, byte[] CertificateName, byte[] imageName) {
        this.studentId = studentId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.faculty = faculty;
        this.department = department;
        this.dob = dob;
        this.CertificateName = CertificateName;
        this.imageName = imageName;
    }

    public Admission(Long studentId, String email, String firstName, String lastName, String gender, String faculty, String department, Date dob) {
        this.studentId = studentId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.faculty = faculty;
        this.department = department;
        this.dob = dob;
    }

    

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public byte[] getCertificateName() {
        return CertificateName;
    }

    public void setCertificateName(byte[] CertificateName) {
        this.CertificateName = CertificateName;
    }

    public byte[] getImageName() {
        return imageName;
    }

    public void setImageName(byte[] imageName) {
        this.imageName = imageName;
    }


    public String getBase64Image() {
        return base64Image;
    }

    public void setBase64Image(String base64Image) {
        this.base64Image = base64Image;
    }

    public String getBase64Pdf() {
        return base64Pdf;
    }

    public void setBase64Pdf(String base64Pdf) {
        this.base64Pdf = base64Pdf;
    }
    public Date getDob() {
        return dob;
    }

    public String getDateOfBirth() {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        if (this.dob != null) {
            return formatter.format(this.dob);
        }
        return "";
    }
    public void setDob(Date dob) {
        this.dob = dob;
    }
}
